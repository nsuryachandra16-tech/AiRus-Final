# AiRus - AI College Assistant

## Overview

AiRus is an AI-powered college companion application designed to help students manage their academic life effectively. The platform provides comprehensive tools for assignment tracking, course scheduling, study session management with a Pomodoro timer, and an AI tutor powered by Google's Gemini API. The application features a dark glassmorphism design aesthetic with warm yellow accents, creating a calm and focused environment for students.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System:**
- React 19.2.0 with TypeScript for type-safe component development
- Vite as the build tool and development server for fast hot-module replacement
- Wouter for client-side routing (lightweight React Router alternative)

**UI Component Library:**
- Shadcn UI component system based on Radix UI primitives
- Tailwind CSS for styling with custom design tokens
- Dark mode by default with glassmorphism aesthetic
- Custom color palette featuring warm yellow (#facc15) as primary accent

**State Management:**
- TanStack React Query (v5) for server state management and caching
- React hooks for local component state
- No global state management library (Redux/Zustand) - relies on React Query's built-in caching

**Design System:**
- Custom CSS variables defined in `client/src/index.css` for theming
- Glassmorphic cards with `backdrop-filter: blur(12px)` and dark semi-transparent backgrounds
- System font stack for performance with JetBrains Mono for timer display
- Responsive design with mobile-first approach

### Backend Architecture

**Server Framework:**
- Express.js with TypeScript for RESTful API endpoints
- Node.js runtime environment
- ESM module system (type: "module" in package.json)

**API Design:**
- RESTful endpoints organized by feature domain:
  - `/api/assignments` - CRUD operations for assignment management
  - `/api/schedule` - Course schedule and event management
  - `/api/study-sessions` - Pomodoro timer session tracking
  - `/api/chat` - AI tutor conversation management
- Standard HTTP methods (GET, POST, PATCH, DELETE)
- JSON request/response format

**Data Persistence Strategy:**
- Dual storage approach: In-memory storage (MemStorage class) for development and rapid prototyping
- Drizzle ORM configured for PostgreSQL production database
- Storage abstraction through IStorage interface allows switching between implementations
- Session-based data structure with no user authentication currently implemented

### Database Design

**ORM & Schema:**
- Drizzle ORM for type-safe database queries and migrations
- Schema definitions in `shared/schema.ts` with Zod validation
- PostgreSQL as target database (configured via Neon serverless driver)

**Data Models:**
1. **Assignments** - Task tracking with course association, due dates, priority levels, and completion status
2. **Schedule Events** - Recurring course schedule with day-of-week mapping, time slots, and locations
3. **Study Sessions** - Pomodoro session tracking with duration and completion timestamps
4. **Chat Messages** - Conversation history for AI tutor feature with role-based message structure

**Schema Features:**
- UUID primary keys using `gen_random_uuid()`
- Timestamp fields with automatic `now()` defaults
- Zod schemas derived from Drizzle tables for runtime validation
- Separate insert schemas excluding auto-generated fields

### External Dependencies

**AI Integration:**
- Google Gemini API (v1.25.0) via `@google/genai` package
- Model: gemini-2.5-flash for AI tutor responses
- System prompts configure the AI as a supportive academic tutor
- Conversation history maintained for context-aware responses
- API key stored in environment variable `GEMINI_API_KEY`

**Third-Party Services:**
- Neon Database - Serverless PostgreSQL hosting (via `@neondatabase/serverless`)
- Google Fonts API - JetBrains Mono font for monospaced timer display

**Development Tools:**
- Replit-specific plugins for development environment integration
- Error overlay and cartographer plugins for debugging
- TypeScript compiler for type checking without emit
- ESBuild for production server bundle compilation

**Notable Library Choices:**
- date-fns for date manipulation (chosen over moment.js for tree-shaking)
- React Hook Form with Zod resolver for form validation
- connect-pg-simple for potential session storage (PostgreSQL-backed sessions)
- class-variance-authority (CVA) for component variant management

### Architecture Decisions

**Monorepo Structure:**
- Shared types and schemas in `/shared` directory consumed by both client and server
- Eliminates type duplication and ensures consistency
- Path aliases configured in tsconfig.json (`@/`, `@shared/`, `@assets/`)

**Type Safety:**
- End-to-end type safety from database to frontend
- Drizzle generates TypeScript types from schema
- Zod provides runtime validation matching compile-time types
- No `any` types in critical paths

**Error Handling:**
- Centralized error middleware in Express
- React Query handles API errors with automatic retry logic
- Toast notifications for user-facing error messages

**Performance Considerations:**
- React Query caching reduces unnecessary API calls
- Vite's development server provides instant HMR
- Production build uses code splitting by default
- Infinite stale time configured to minimize refetches