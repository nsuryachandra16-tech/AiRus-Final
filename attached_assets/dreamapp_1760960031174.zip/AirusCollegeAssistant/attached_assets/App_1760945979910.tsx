import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import SearchComponent from './components/SearchComponent';
import ResultsDisplay from './components/ResultsDisplay';
import { fetchProductPrices } from './services/geminiService';
import type { Product } from './types';

const App: React.FC = () => {
  const [searchResults, setSearchResults] = useState<Product[] | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = useCallback(async (query: string) => {
    if (!query.trim()) return;

    setIsLoading(true);
    setError(null);
    setSearchResults(null);

    try {
      const prompt = `Find product prices for: "${query}"`;
        
      const results = await fetchProductPrices(prompt);
      
      if (results.length === 0) {
        setError('No products found matching your query. Please try a different search term.');
      } else {
        setSearchResults(results);
      }

    } catch (err) {
      console.error(err);
      setError('An error occurred while fetching prices. Please check your connection or try again later.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-800">
      <Header />
      <main className="container mx-auto p-4 md:p-8">
        <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-lg p-6 md:p-8 space-y-8">
          <div className="text-center">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Find the Best Price</h2>
            <p className="text-gray-500 mt-2">Search by product name to start comparing.</p>
          </div>
          <SearchComponent onSearch={handleSearch} isLoading={isLoading} />
        </div>
        
        <div className="mt-12 max-w-5xl mx-auto">
          <ResultsDisplay 
            products={searchResults}
            isLoading={isLoading}
            error={error}
          />
        </div>
      </main>
      <footer className="text-center p-4 text-gray-400 text-sm mt-8">
        <p>&copy; 2024 AiRus Comparison. Prices are sourced from real-time search and may vary.</p>
      </footer>
    </div>
  );
};

export default App;