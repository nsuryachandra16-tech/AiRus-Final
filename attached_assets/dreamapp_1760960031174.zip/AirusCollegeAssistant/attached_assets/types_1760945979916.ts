
export enum Platform {
  Flipkart = 'Flipkart',
  Amazon = 'Amazon',
  Myntra = 'Myntra',
}

export interface Listing {
  platform: Platform;
  price: number;
  url: string;
}

export interface Product {
  name: string;
  description: string;
  imageUrl: string;
  listings: Listing[];
}
