import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Helper function to generate UUIDs (assuming this is defined elsewhere or needs to be defined)
// For the purpose of this example, let's assume a simple placeholder or that it's imported.
// If 'generateId' is not defined, the code would fail.
// In a real scenario, you'd import it or define it:
// import { generateId } from './utils'; // Example import
// Or define it here:
const generateId = () => Math.random().toString(36).substring(2, 15);


// Assignments table
export const assignments = pgTable("assignments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  courseName: text("course_name").notNull(),
  courseColor: text("course_color").notNull().default("#facc15"),
  dueDate: timestamp("due_date").notNull(),
  priority: text("priority").notNull().default("medium"), // low, medium, high
  completed: boolean("completed").notNull().default(false),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const insertAssignmentSchema = createInsertSchema(assignments).omit({
  id: true,
  createdAt: true,
});

export type InsertAssignment = z.infer<typeof insertAssignmentSchema>;
export type Assignment = typeof assignments.$inferSelect;

// Schedule events table
export const scheduleEvents = pgTable("schedule_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  courseName: text("course_name").notNull(),
  courseColor: text("course_color").notNull().default("#facc15"),
  location: text("location"),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  dayOfWeek: integer("day_of_week").notNull(), // 0-6 (Sunday-Saturday)
  recurring: boolean("recurring").notNull().default(true),
});

export const insertScheduleEventSchema = createInsertSchema(scheduleEvents).omit({
  id: true,
});

export type InsertScheduleEvent = z.infer<typeof insertScheduleEventSchema>;
export type ScheduleEvent = typeof scheduleEvents.$inferSelect;

// Study sessions table
export const studySessions = pgTable("study_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  duration: integer("duration").notNull(), // in seconds
  type: text("type").notNull().default("study"), // study, break
  startedAt: timestamp("started_at").notNull().default(sql`now()`),
  completedAt: timestamp("completed_at"),
});

export const insertStudySessionSchema = createInsertSchema(studySessions).omit({
  id: true,
  startedAt: true,
});

export type InsertStudySession = z.infer<typeof insertStudySessionSchema>;
export type StudySession = typeof studySessions.$inferSelect;

// Chat messages table
export const chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  role: text("role").notNull(), // user, assistant
  content: text("content").notNull(),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true,
});

export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;

// Users table (keeping original)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// User Profile table
export const userProfiles = pgTable("user_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email"),
  avatar: text("avatar"),
  college: text("college"),
  major: text("major"),
  graduationYear: integer("graduation_year"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const insertUserProfileSchema = createInsertSchema(userProfiles).omit({
  id: true,
  createdAt: true,
});

export type InsertUserProfile = z.infer<typeof insertUserProfileSchema>;
export type UserProfile = typeof userProfiles.$inferSelect;



// Timetable entries table
export const timetableEntries = pgTable("timetable_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dayOfWeek: integer("day_of_week").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  subject: text("subject").notNull(),
  type: text("type").notNull().default("class"), // class, lab, break
  location: text("location"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const insertTimetableEntrySchema = createInsertSchema(timetableEntries).omit({
  id: true,
  createdAt: true,
});

export type InsertTimetableEntry = z.infer<typeof insertTimetableEntrySchema>;
export type TimetableEntry = typeof timetableEntries.$inferSelect;

// Free slots table (auto-generated from timetable)
export const freeSlots = pgTable("free_slots", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dayOfWeek: integer("day_of_week").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  duration: integer("duration").notNull(), // in minutes
  isAvailable: boolean("is_available").notNull().default(true),
});

export const insertFreeSlotSchema = createInsertSchema(freeSlots).omit({
  id: true,
});

export type InsertFreeSlot = z.infer<typeof insertFreeSlotSchema>;
export type FreeSlot = typeof freeSlots.$inferSelect;


// Work items table (modified from original, but the changes provided didn't alter this structure, only added new tables)
export const workItems = pgTable("work_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  subject: text("subject").notNull(),
  estimatedDuration: integer("estimated_duration").notNull(), // in minutes
  priority: text("priority").notNull().default("medium"),
  dueDate: timestamp("due_date"),
  scheduledSlotId: varchar("scheduled_slot_id"),
  completed: boolean("completed").notNull().default(false),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const insertWorkItemSchema = createInsertSchema(workItems).omit({
  id: true,
  createdAt: true,
});

export type InsertWorkItem = z.infer<typeof insertWorkItemSchema>;
export type WorkItem = typeof workItems.$inferSelect;


// New tables for Study Analytics and Assignment Intelligence
export const studyAnalytics = pgTable("study_analytics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: timestamp("date").notNull(),
  hourOfDay: integer("hour_of_day").notNull(),
  productivityScore: integer("productivity_score").notNull(), // 1-10
  focusDuration: integer("focus_duration").notNull(), // in seconds
  tasksCompleted: integer("tasks_completed").notNull().default(0),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const assignmentInsights = pgTable("assignment_insights", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  assignmentId: varchar("assignment_id").references(() => assignments.id).notNull(),
  predictedDifficulty: text("predicted_difficulty", { enum: ["easy", "medium", "hard", "very_hard"] }),
  predictedTimeMinutes: integer("predicted_time_minutes"),
  suggestedSubtasks: jsonb("suggested_subtasks").$type<string[]>(),
  aiAnalysis: text("ai_analysis"),
  actualTimeSpent: integer("actual_time_spent"), // in minutes
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

// Insert schemas for new features
export const insertStudyAnalyticsSchema = createInsertSchema(studyAnalytics).omit({
  id: true,
  createdAt: true,
});

export const insertAssignmentInsightSchema = createInsertSchema(assignmentInsights).omit({
  id: true,
  createdAt: true,
});

// TypeScript types for new features
export type StudyAnalytics = typeof studyAnalytics.$inferSelect;
export type InsertStudyAnalytics = typeof studyAnalytics.$inferInsert;

export type AssignmentInsight = typeof assignmentInsights.$inferSelect;
export type InsertAssignmentInsight = typeof assignmentInsights.$inferInsert;