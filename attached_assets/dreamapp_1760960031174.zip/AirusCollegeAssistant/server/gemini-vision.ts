
import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");

export async function analyzeTimetableImage(base64Image: string) {
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" });

    const prompt = `Analyze this college timetable image and extract the schedule information. 
    Return a JSON array of objects with this structure:
    [
      {
        "dayOfWeek": 0-6 (0=Sunday, 1=Monday, etc.),
        "startTime": "HH:MM" (24-hour format),
        "endTime": "HH:MM" (24-hour format),
        "subject": "Subject name",
        "type": "class" or "lab" or "break",
        "location": "Room/Location if available"
      }
    ]
    
    Only return valid JSON, no markdown or extra text.`;

    const imagePart = {
      inlineData: {
        data: base64Image,
        mimeType: "image/jpeg",
      },
    };

    const result = await model.generateContent([prompt, imagePart]);
    const response = await result.response;
    const text = response.text();
    
    // Clean up response to get valid JSON
    const jsonMatch = text.match(/\[[\s\S]*\]/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
    
    throw new Error("Could not parse timetable from image");
  } catch (error) {
    console.error("Timetable analysis error:", error);
    throw error;
  }
}

export async function analyzeWorkImage(base64Image: string) {
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" });

    const prompt = `Analyze this homework/assignment image and extract the work details.
    Return a JSON object with this structure:
    {
      "title": "Brief title of the work",
      "description": "Detailed description of what needs to be done",
      "subject": "Subject/Course name",
      "estimatedDuration": number (estimated minutes to complete),
      "priority": "low" or "medium" or "high",
      "dueDate": "YYYY-MM-DD" or null if not specified
    }
    
    Only return valid JSON, no markdown or extra text.`;

    const imagePart = {
      inlineData: {
        data: base64Image,
        mimeType: "image/jpeg",
      },
    };

    const result = await model.generateContent([prompt, imagePart]);
    const response = await result.response;
    const text = response.text();
    
    // Clean up response to get valid JSON
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
    
    throw new Error("Could not parse work from image");
  } catch (error) {
    console.error("Work analysis error:", error);
    throw error;
  }
}
