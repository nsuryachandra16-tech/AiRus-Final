// DON'T DELETE THIS COMMENT
// Follow these instructions when using this blueprint:
// - Note that the newest Gemini model series is "gemini-2.5-flash" or gemini-2.5-pro"
//   - do not change this unless explicitly requested by the user

import { GoogleGenAI } from "@google/genai";

// This API key is from Gemini Developer API Key, not vertex AI API Key
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function chatWithTutor(userMessage: string, conversationHistory: { role: string; content: string }[]): Promise<string> {
  try {
    const systemPrompt = `You are AiRus, a helpful and friendly AI tutor for college students. Your role is STRICTLY LIMITED to academic and study-related topics only.

IMPORTANT RULES:
- ONLY answer questions related to: academics, homework, assignments, studying, learning strategies, exam preparation, course subjects, educational concepts, time management for studies, and college coursework
- If a user asks about anything NOT related to studies or academics (like entertainment, personal life, general chat, news, etc.), politely redirect them by saying: "I'm here to help with your studies and academic questions only. Please ask me something related to your coursework, assignments, or learning!"
- Stay focused on being an educational assistant
- Help students understand complex concepts in a clear, accessible way
- Provide study tips and learning strategies
- Encourage critical thinking and problem-solving
- Be supportive and motivating about their academic journey

Keep your responses concise, clear, and educational. Use examples when helpful for academic topics.`;

    // Convert conversation history to Gemini format
    const contents = conversationHistory.map((msg) => ({
      role: msg.role === "assistant" ? "model" : "user",
      parts: [{ text: msg.content }],
    }));

    // Add the new user message
    contents.push({
      role: "user",
      parts: [{ text: userMessage }],
    });

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
      },
      contents: contents,
    });

    return response.text || "I'm sorry, I couldn't generate a response. Please try again.";
  } catch (error) {
    console.error("Gemini API error:", error);
    throw new Error(`Failed to get response from AI tutor: ${error}`);
  }
}
