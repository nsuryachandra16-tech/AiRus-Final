import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { chatWithTutor } from "./gemini";
import { analyzeTimetableImage, analyzeWorkImage } from "./gemini-vision";
import { analyzeAssignment } from "./gemini-insights";
import { insertAssignmentSchema, insertScheduleEventSchema, insertStudySessionSchema, insertChatMessageSchema, insertTimetableEntrySchema, insertWorkItemSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // User Profile routes
  app.get("/api/profile", async (_req, res) => {
    try {
      const profile = await storage.getUserProfile();
      res.json(profile || null);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch profile" });
    }
  });

  app.post("/api/profile", async (req, res) => {
    try {
      const profile = await storage.createUserProfile(req.body);
      res.json(profile);
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Invalid profile data" });
    }
  });

  app.patch("/api/profile/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const profile = await storage.updateUserProfile(id, req.body);
      if (!profile) {
        return res.status(404).json({ error: "Profile not found" });
      }
      res.json(profile);
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Failed to update profile" });
    }
  });

  // Assignments routes
  app.get("/api/assignments", async (_req, res) => {
    try {
      const assignments = await storage.getAssignments();
      res.json(assignments);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch assignments" });
    }
  });

  app.post("/api/assignments", async (req, res) => {
    try {
      const validatedData = insertAssignmentSchema.parse(req.body);
      const assignment = await storage.createAssignment(validatedData);
      
      // Generate AI insights for the assignment
      try {
        const insights = await analyzeAssignment(
          assignment.title,
          assignment.description || "",
          assignment.courseName
        );
        
        await storage.createAssignmentInsight({
          assignmentId: assignment.id,
          predictedDifficulty: insights.difficulty,
          predictedTimeMinutes: insights.estimatedMinutes,
          suggestedSubtasks: insights.subtasks,
          aiAnalysis: insights.analysis,
        });
      } catch (insightError) {
        console.error("Failed to generate assignment insights:", insightError);
      }
      
      res.json(assignment);
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Invalid assignment data" });
    }
  });

  app.patch("/api/assignments/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const assignment = await storage.updateAssignment(id, req.body);
      if (!assignment) {
        return res.status(404).json({ error: "Assignment not found" });
      }
      res.json(assignment);
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Failed to update assignment" });
    }
  });

  app.delete("/api/assignments/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteAssignment(id);
      if (!deleted) {
        return res.status(404).json({ error: "Assignment not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete assignment" });
    }
  });

  // Schedule events routes
  app.get("/api/schedule", async (_req, res) => {
    try {
      const events = await storage.getScheduleEvents();
      res.json(events);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch schedule events" });
    }
  });

  app.post("/api/schedule", async (req, res) => {
    try {
      const validatedData = insertScheduleEventSchema.parse(req.body);
      const event = await storage.createScheduleEvent(validatedData);
      res.json(event);
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Invalid event data" });
    }
  });

  app.patch("/api/schedule/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const event = await storage.updateScheduleEvent(id, req.body);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      res.json(event);
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Failed to update event" });
    }
  });

  app.delete("/api/schedule/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteScheduleEvent(id);
      if (!deleted) {
        return res.status(404).json({ error: "Event not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete event" });
    }
  });

  // Study sessions routes
  app.get("/api/study-sessions", async (_req, res) => {
    try {
      const sessions = await storage.getStudySessions();
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch study sessions" });
    }
  });

  app.post("/api/study-sessions", async (req, res) => {
    try {
      const validatedData = insertStudySessionSchema.parse(req.body);
      const session = await storage.createStudySession(validatedData);
      res.json(session);
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Invalid session data" });
    }
  });

  app.patch("/api/study-sessions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const session = await storage.updateStudySession(id, req.body);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json(session);
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Failed to update session" });
    }
  });

  // Chat routes with Gemini AI integration
  app.get("/api/chat", async (_req, res) => {
    try {
      const messages = await storage.getChatMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch chat messages" });
    }
  });

  app.post("/api/chat", async (req, res) => {
    try {
      const { content } = req.body;
      
      if (!content || typeof content !== "string") {
        return res.status(400).json({ error: "Message content is required" });
      }

      // Save user message
      const userMessage = await storage.createChatMessage({
        role: "user",
        content,
      });

      // Get conversation history
      const history = await storage.getChatMessages();
      const conversationHistory = history
        .slice(-10) // Last 10 messages for context
        .map((msg) => ({
          role: msg.role,
          content: msg.content,
        }));

      // Get AI response
      const aiResponse = await chatWithTutor(content, conversationHistory);

      // Save AI message
      const assistantMessage = await storage.createChatMessage({
        role: "assistant",
        content: aiResponse,
      });

      res.json({ userMessage, assistantMessage });
    } catch (error: any) {
      console.error("Chat error:", error);
      res.status(500).json({ error: error.message || "Failed to process chat message" });
    }
  });

  app.delete("/api/chat", async (_req, res) => {
    try {
      await storage.clearChatMessages();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to clear chat messages" });
    }
  });

  // Timetable routes
  app.get("/api/timetable", async (_req, res) => {
    try {
      const entries = await storage.getTimetableEntries();
      res.json(entries);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch timetable" });
    }
  });

  app.post("/api/timetable/upload", async (req, res) => {
    try {
      const { image } = req.body;
      
      if (!image || typeof image !== 'string') {
        return res.status(400).json({ error: "Valid image data is required" });
      }

      // Validate base64 format
      if (!image.match(/^[A-Za-z0-9+/=]+$/)) {
        return res.status(400).json({ error: "Invalid image format" });
      }

      console.log("Analyzing timetable image...");
      
      // Analyze image with Gemini Vision
      const entries = await analyzeTimetableImage(image);
      
      if (!entries || !Array.isArray(entries) || entries.length === 0) {
        return res.status(400).json({ error: "No timetable data could be extracted from the image" });
      }

      console.log(`Extracted ${entries.length} timetable entries`);
      
      // Clear existing timetable and slots
      await storage.clearTimetable();
      await storage.clearFreeSlots();

      // Save new timetable entries
      const savedEntries = [];
      for (const entry of entries) {
        const saved = await storage.createTimetableEntry(entry);
        savedEntries.push(saved);
      }

      // Generate free slots
      const freeSlots = generateFreeSlots(savedEntries);
      console.log(`Generated ${freeSlots.length} free slots`);
      
      for (const slot of freeSlots) {
        await storage.createFreeSlot(slot);
      }

      res.json({ entries: savedEntries, freeSlots });
    } catch (error: any) {
      console.error("Timetable upload error:", error);
      res.status(500).json({ error: error.message || "Failed to process timetable" });
    }
  });

  app.delete("/api/timetable", async (_req, res) => {
    try {
      await storage.clearTimetable();
      await storage.clearFreeSlots();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to clear timetable" });
    }
  });

  // Work items routes
  app.get("/api/work", async (_req, res) => {
    try {
      const items = await storage.getWorkItems();
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch work items" });
    }
  });

  app.post("/api/work/upload", async (req, res) => {
    try {
      const { image } = req.body;
      
      if (!image || typeof image !== 'string') {
        return res.status(400).json({ error: "Valid image data is required" });
      }

      // Validate base64 format
      if (!image.match(/^[A-Za-z0-9+/=]+$/)) {
        return res.status(400).json({ error: "Invalid image format" });
      }

      console.log("Analyzing work image...");

      // Analyze work image
      const workData = await analyzeWorkImage(image);
      
      if (!workData || !workData.title) {
        return res.status(400).json({ error: "Could not extract work information from the image" });
      }

      console.log(`Extracted work: ${workData.title}`);
      
      // Create work item
      const workItem = await storage.createWorkItem({
        ...workData,
        imageUrl: image.substring(0, 200), // Store truncated version to save memory
        dueDate: workData.dueDate ? new Date(workData.dueDate) : null,
      });

      // Auto-schedule in free slot
      const freeSlots = await storage.getFreeSlots();
      const availableSlot = freeSlots.find(
        slot => slot.isAvailable && slot.duration >= workData.estimatedDuration
      );

      if (availableSlot) {
        console.log(`Scheduled work in slot: ${availableSlot.startTime}-${availableSlot.endTime}`);
        await storage.updateWorkItem(workItem.id, { scheduledSlotId: availableSlot.id });
        await storage.updateFreeSlot(availableSlot.id, { isAvailable: false });
      } else {
        console.log("No available slot found for this work");
      }

      res.json(workItem);
    } catch (error: any) {
      console.error("Work upload error:", error);
      res.status(500).json({ error: error.message || "Failed to process work" });
    }
  });

  app.patch("/api/work/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const work = await storage.updateWorkItem(id, req.body);
      if (!work) {
        return res.status(404).json({ error: "Work item not found" });
      }
      res.json(work);
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Failed to update work" });
    }
  });

  app.delete("/api/work/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteWorkItem(id);
      if (!deleted) {
        return res.status(404).json({ error: "Work item not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete work item" });
    }
  });

  // Free slots routes
  app.get("/api/slots", async (_req, res) => {
    try {
      const slots = await storage.getFreeSlots();
      res.json(slots);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch free slots" });
    }
  });

  // Study Analytics routes
  app.post("/api/analytics/study", async (req, res) => {
    try {
      const { productivityScore, focusDuration, tasksCompleted } = req.body;
      const now = new Date();
      
      const analytics = await storage.createStudyAnalytics({
        date: now,
        hourOfDay: now.getHours(),
        productivityScore,
        focusDuration,
        tasksCompleted,
      });
      
      res.json(analytics);
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Failed to save analytics" });
    }
  });

  app.get("/api/analytics/best-hours", async (_req, res) => {
    try {
      const bestHours = await storage.getBestStudyHours();
      res.json(bestHours);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch best study hours" });
    }
  });

  app.get("/api/analytics/study", async (req, res) => {
    try {
      const days = parseInt(req.query.days as string) || 30;
      const analytics = await storage.getStudyAnalytics(days);
      res.json(analytics);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch analytics" });
    }
  });

  // Assignment Insights routes
  app.get("/api/insights/:assignmentId", async (req, res) => {
    try {
      const { assignmentId } = req.params;
      const insight = await storage.getAssignmentInsight(assignmentId);
      res.json(insight);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch assignment insights" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}

// Helper function to generate free slots from timetable
function generateFreeSlots(entries: any[]): any[] {
  const slots: any[] = [];
  const DAYS = 7;
  const START_TIME = "08:00";
  const END_TIME = "18:00";

  for (let day = 0; day < DAYS; day++) {
    const dayEntries = entries
      .filter(e => e.dayOfWeek === day)
      .sort((a, b) => a.startTime.localeCompare(b.startTime));

    if (dayEntries.length === 0) continue;

    let currentTime = START_TIME;

    for (const entry of dayEntries) {
      if (currentTime < entry.startTime) {
        const duration = calculateDuration(currentTime, entry.startTime);
        if (duration >= 30) { // Only add slots >= 30 minutes
          slots.push({
            dayOfWeek: day,
            startTime: currentTime,
            endTime: entry.startTime,
            duration,
            isAvailable: true,
          });
        }
      }
      currentTime = entry.endTime;
    }

    // Add remaining time after last class
    if (currentTime < END_TIME) {
      const duration = calculateDuration(currentTime, END_TIME);
      if (duration >= 30) {
        slots.push({
          dayOfWeek: day,
          startTime: currentTime,
          endTime: END_TIME,
          duration,
          isAvailable: true,
        });
      }
    }
  }

  return slots;
}

function calculateDuration(start: string, end: string): number {
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  return (eh * 60 + em) - (sh * 60 + sm);
}
