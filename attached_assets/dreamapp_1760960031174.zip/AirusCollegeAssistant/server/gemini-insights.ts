
import { GoogleGenerativeAI } from "@google/generative-ai";

const apiKey = process.env.GEMINI_API_KEY;

if (!apiKey) {
  throw new Error("GEMINI_API_KEY is not set in environment variables");
}

const genAI = new GoogleGenerativeAI(apiKey);

export async function analyzeAssignment(title: string, description: string, courseName: string): Promise<{
  difficulty: "easy" | "medium" | "hard" | "very_hard";
  estimatedMinutes: number;
  subtasks: string[];
  analysis: string;
}> {
  const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" });

  const prompt = `You are an academic assignment analyzer. Analyze this college assignment and provide insights:

Assignment Title: ${title}
Course: ${courseName}
Description: ${description || "No description provided"}

Please respond with a JSON object containing:
1. difficulty: "easy", "medium", "hard", or "very_hard"
2. estimatedMinutes: number (estimated time to complete)
3. subtasks: array of 3-5 actionable subtasks to break down the assignment
4. analysis: brief text explaining the difficulty and time estimate

Example response:
{
  "difficulty": "medium",
  "estimatedMinutes": 120,
  "subtasks": ["Research topic background", "Create outline", "Write first draft", "Review and edit", "Format citations"],
  "analysis": "This essay requires research and critical thinking. Medium difficulty due to analytical requirements. Estimated 2 hours for a thorough completion."
}

Respond ONLY with valid JSON, no markdown or extra text.`;

  try {
    const result = await model.generateContent(prompt);
    const text = result.response.text();
    
    // Remove markdown code blocks if present
    const jsonText = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
    const parsed = JSON.parse(jsonText);
    
    return {
      difficulty: parsed.difficulty,
      estimatedMinutes: parsed.estimatedMinutes,
      subtasks: parsed.subtasks,
      analysis: parsed.analysis,
    };
  } catch (error) {
    console.error("Error analyzing assignment:", error);
    // Return default values if AI analysis fails
    return {
      difficulty: "medium",
      estimatedMinutes: 60,
      subtasks: ["Start the assignment", "Complete main work", "Review and finalize"],
      analysis: "Assignment analysis unavailable. Default estimates provided.",
    };
  }
}
