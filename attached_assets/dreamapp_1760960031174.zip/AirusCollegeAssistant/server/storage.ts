import { type User, type InsertUser, type Assignment, type InsertAssignment, type ScheduleEvent, type InsertScheduleEvent, type StudySession, type InsertStudySession, type ChatMessage, type InsertChatMessage, type TimetableEntry, type InsertTimetableEntry, type WorkItem, type InsertWorkItem, type FreeSlot, type InsertFreeSlot, type UserProfile, type InsertUserProfile } from "@shared/schema";
import { assignments, scheduleEvents, studySessions, chatMessages, timetableEntries, freeSlots, workItems, studyAnalytics, assignmentInsights, userProfiles } from "@shared/schema";
import type { Assignment, ScheduleEvent, StudySession, ChatMessage, TimetableEntry, FreeSlot, WorkItem, StudyAnalytics, AssignmentInsight, InsertAssignment, InsertScheduleEvent, InsertStudySession, InsertChatMessage, InsertTimetableEntry, InsertFreeSlot, InsertWorkItem, InsertStudyAnalytics, InsertAssignmentInsight } from "@shared/schema";
import { randomUUID } from "crypto";
import { desc, eq, sql } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // User Profiles
  getUserProfile(): Promise<UserProfile | undefined>;
  createUserProfile(profile: InsertUserProfile): Promise<UserProfile>;
  updateUserProfile(id: string, profile: Partial<UserProfile>): Promise<UserProfile | undefined>;

  // Assignments
  getAssignments(): Promise<Assignment[]>;
  getAssignment(id: string): Promise<Assignment | undefined>;
  createAssignment(assignment: InsertAssignment): Promise<Assignment>;
  updateAssignment(id: string, assignment: Partial<Assignment>): Promise<Assignment | undefined>;
  deleteAssignment(id: string): Promise<boolean>;

  // Schedule Events
  getScheduleEvents(): Promise<ScheduleEvent[]>;
  getScheduleEvent(id: string): Promise<ScheduleEvent | undefined>;
  createScheduleEvent(event: InsertScheduleEvent): Promise<ScheduleEvent>;
  updateScheduleEvent(id: string, event: Partial<ScheduleEvent>): Promise<ScheduleEvent | undefined>;
  deleteScheduleEvent(id: string): Promise<boolean>;

  // Study Sessions
  getStudySessions(): Promise<StudySession[]>;
  getStudySession(id: string): Promise<StudySession | undefined>;
  createStudySession(session: InsertStudySession): Promise<StudySession>;
  updateStudySession(id: string, session: Partial<StudySession>): Promise<StudySession | undefined>;

  // Chat Messages
  getChatMessages(): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  clearChatMessages(): Promise<void>;

  // Timetable Entries
  getTimetableEntries(): Promise<TimetableEntry[]>;
  createTimetableEntry(entry: InsertTimetableEntry): Promise<TimetableEntry>;
  clearTimetable(): Promise<void>;

  // Work Items
  getWorkItems(): Promise<WorkItem[]>;
  createWorkItem(work: InsertWorkItem): Promise<WorkItem>;
  updateWorkItem(id: string, work: Partial<WorkItem>): Promise<WorkItem | undefined>;
  deleteWorkItem(id: string): Promise<boolean>;

  // Free Slots
  getFreeSlots(): Promise<FreeSlot[]>;
  createFreeSlot(slot: InsertFreeSlot): Promise<FreeSlot>;
  updateFreeSlot(id: string, slot: Partial<FreeSlot>): Promise<FreeSlot | undefined>;
  clearFreeSlots(): Promise<void>;

  // Study Analytics
  createStudyAnalytics(data: InsertStudyAnalytics): Promise<StudyAnalytics>;
  getStudyAnalytics(days?: number): Promise<StudyAnalytics[]>;
  getBestStudyHours(): Promise<{ hour: number; avgScore: number }[]>;

  // Assignment Insights
  createAssignmentInsight(data: InsertAssignmentInsight): Promise<AssignmentInsight>;
  getAssignmentInsight(assignmentId: string): Promise<AssignmentInsight | undefined>;
  updateAssignmentInsight(id: string, data: Partial<AssignmentInsight>): Promise<AssignmentInsight | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private assignments: Map<string, Assignment>;
  private scheduleEvents: Map<string, ScheduleEvent>;
  private studySessions: Map<string, StudySession>;
  private chatMessages: Map<string, ChatMessage>;
  private timetableEntries: Map<string, TimetableEntry>;
  private workItems: Map<string, WorkItem>;
  private freeSlots: Map<string, FreeSlot>;
  private analytics: Map<string, StudyAnalytics>;
  private insights: Map<string, AssignmentInsight>;

  private userProfile: UserProfile | undefined;

  constructor() {
    this.users = new Map();
    this.assignments = new Map();
    this.scheduleEvents = new Map();
    this.studySessions = new Map();
    this.chatMessages = new Map();
    this.timetableEntries = new Map();
    this.workItems = new Map();
    this.freeSlots = new Map();
    this.analytics = new Map();
    this.insights = new Map();
    this.userProfile = undefined;
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Assignments
  async getAssignments(): Promise<Assignment[]> {
    return Array.from(this.assignments.values());
  }

  async getAssignment(id: string): Promise<Assignment | undefined> {
    return this.assignments.get(id);
  }

  async createAssignment(insertAssignment: InsertAssignment): Promise<Assignment> {
    const id = randomUUID();
    const assignment: Assignment = {
      ...insertAssignment,
      id,
      createdAt: new Date(),
    };
    this.assignments.set(id, assignment);
    return assignment;
  }

  async updateAssignment(id: string, update: Partial<Assignment>): Promise<Assignment | undefined> {
    const assignment = this.assignments.get(id);
    if (!assignment) return undefined;
    const updated = { ...assignment, ...update };
    this.assignments.set(id, updated);
    return updated;
  }

  async deleteAssignment(id: string): Promise<boolean> {
    return this.assignments.delete(id);
  }

  // Schedule Events
  async getScheduleEvents(): Promise<ScheduleEvent[]> {
    return Array.from(this.scheduleEvents.values());
  }

  async getScheduleEvent(id: string): Promise<ScheduleEvent | undefined> {
    return this.scheduleEvents.get(id);
  }

  async createScheduleEvent(insertEvent: InsertScheduleEvent): Promise<ScheduleEvent> {
    const id = randomUUID();
    const event: ScheduleEvent = {
      ...insertEvent,
      id,
    };
    this.scheduleEvents.set(id, event);
    return event;
  }

  async updateScheduleEvent(id: string, update: Partial<ScheduleEvent>): Promise<ScheduleEvent | undefined> {
    const event = this.scheduleEvents.get(id);
    if (!event) return undefined;
    const updated = { ...event, ...update };
    this.scheduleEvents.set(id, updated);
    return updated;
  }

  async deleteScheduleEvent(id: string): Promise<boolean> {
    return this.scheduleEvents.delete(id);
  }

  // Study Sessions
  async getStudySessions(): Promise<StudySession[]> {
    return Array.from(this.studySessions.values());
  }

  async getStudySession(id: string): Promise<StudySession | undefined> {
    return this.studySessions.get(id);
  }

  async createStudySession(insertSession: InsertStudySession): Promise<StudySession> {
    const id = randomUUID();
    const session: StudySession = {
      ...insertSession,
      id,
      startedAt: new Date(),
      completedAt: null,
    };
    this.studySessions.set(id, session);
    return session;
  }

  async updateStudySession(id: string, update: Partial<StudySession>): Promise<StudySession | undefined> {
    const session = this.studySessions.get(id);
    if (!session) return undefined;
    const updated = { ...session, ...update };
    this.studySessions.set(id, updated);
    return updated;
  }

  // Chat Messages
  async getChatMessages(): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values()).sort(
      (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
    );
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = randomUUID();
    const message: ChatMessage = {
      ...insertMessage,
      id,
      createdAt: new Date(),
    };
    this.chatMessages.set(id, message);
    return message;
  }

  async clearChatMessages(): Promise<void> {
    this.chatMessages.clear();
  }

  // Timetable Entries
  async getTimetableEntries(): Promise<TimetableEntry[]> {
    return Array.from(this.timetableEntries.values()).sort(
      (a, b) => a.dayOfWeek - b.dayOfWeek
    );
  }

  async createTimetableEntry(insertEntry: InsertTimetableEntry): Promise<TimetableEntry> {
    const id = randomUUID();
    const entry: TimetableEntry = {
      ...insertEntry,
      id,
      createdAt: new Date(),
    };
    this.timetableEntries.set(id, entry);
    return entry;
  }

  async clearTimetable(): Promise<void> {
    this.timetableEntries.clear();
  }

  // Work Items
  async getWorkItems(): Promise<WorkItem[]> {
    return Array.from(this.workItems.values()).sort(
      (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
    );
  }

  async createWorkItem(insertWork: InsertWorkItem): Promise<WorkItem> {
    const id = randomUUID();
    const work: WorkItem = {
      ...insertWork,
      id,
      createdAt: new Date(),
    };
    this.workItems.set(id, work);
    return work;
  }

  async updateWorkItem(id: string, update: Partial<WorkItem>): Promise<WorkItem | undefined> {
    const work = this.workItems.get(id);
    if (!work) return undefined;
    const updated = { ...work, ...update };
    this.workItems.set(id, updated);
    return updated;
  }

  async deleteWorkItem(id: string): Promise<boolean> {
    return this.workItems.delete(id);
  }

  // Free Slots
  async getFreeSlots(): Promise<FreeSlot[]> {
    return Array.from(this.freeSlots.values()).sort(
      (a, b) => a.dayOfWeek - b.dayOfWeek
    );
  }

  async createFreeSlot(insertSlot: InsertFreeSlot): Promise<FreeSlot> {
    const id = randomUUID();
    const slot: FreeSlot = {
      ...insertSlot,
      id,
    };
    this.freeSlots.set(id, slot);
    return slot;
  }

  async updateFreeSlot(id: string, update: Partial<FreeSlot>): Promise<FreeSlot | undefined> {
    const slot = this.freeSlots.get(id);
    if (!slot) return undefined;
    const updated = { ...slot, ...update };
    this.freeSlots.set(id, updated);
    return updated;
  }

  async clearFreeSlots(): Promise<void> {
    this.freeSlots.clear();
  }

  // Study Analytics
  async createStudyAnalytics(data: InsertStudyAnalytics): Promise<StudyAnalytics> {
    const id = randomUUID();
    const analytics: StudyAnalytics = {
      ...data,
      id,
      date: new Date(data.date),
    };
    this.analytics.set(id, analytics);
    return analytics;
  }

  async getStudyAnalytics(days: number = 30): Promise<StudyAnalytics[]> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    
    return Array.from(this.analytics.values())
      .filter(data => new Date(data.date) >= cutoffDate)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  async getBestStudyHours(): Promise<{ hour: number; avgScore: number }[]> {
    const analyticsData = await this.getStudyAnalytics();
    if (analyticsData.length === 0) {
      return [];
    }

    const hourlyScores: { [hour: number]: { sum: number; count: number } } = {};

    analyticsData.forEach(data => {
      const hour = data.hourOfDay;
      if (!hourlyScores[hour]) {
        hourlyScores[hour] = { sum: 0, count: 0 };
      }
      hourlyScores[hour].sum += data.productivityScore;
      hourlyScores[hour].count += 1;
    });

    const avgScores = Object.entries(hourlyScores)
      .map(([hour, data]) => ({
        hour: parseInt(hour, 10),
        avgScore: data.sum / data.count,
      }))
      .filter(([_, data]) => data.count >= 3)
      .sort((a, b) => b.avgScore - a.avgScore)
      .slice(0, 5);

    return avgScores;
  }

  // Assignment Insights
  async createAssignmentInsight(data: InsertAssignmentInsight): Promise<AssignmentInsight> {
    const id = randomUUID();
    const insight: AssignmentInsight = {
      ...data,
      id,
    };
    this.insights.set(id, insight);
    return insight;
  }

  async getAssignmentInsight(assignmentId: string): Promise<AssignmentInsight | undefined> {
    return Array.from(this.insights.values()).find(
      insight => insight.assignmentId === assignmentId
    );
  }

  async updateAssignmentInsight(id: string, data: Partial<AssignmentInsight>): Promise<AssignmentInsight | undefined> {
    const existingInsight = this.insights.get(id);
    if (!existingInsight) {
      return undefined;
    }
    const updatedInsight = { ...existingInsight, ...data };
    this.insights.set(id, updatedInsight);
    return updatedInsight;
  }

  // User Profile
  async getUserProfile(): Promise<UserProfile | undefined> {
    return this.userProfile;
  }

  async createUserProfile(insertProfile: InsertUserProfile): Promise<UserProfile> {
    const id = randomUUID();
    const profile: UserProfile = {
      ...insertProfile,
      id,
      createdAt: new Date(),
    };
    this.userProfile = profile;
    return profile;
  }

  async updateUserProfile(id: string, update: Partial<UserProfile>): Promise<UserProfile | undefined> {
    if (!this.userProfile || this.userProfile.id !== id) return undefined;
    const updated = { ...this.userProfile, ...update };
    this.userProfile = updated;
    return updated;
  }
}

export const storage = new MemStorage();