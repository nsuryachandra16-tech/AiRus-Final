import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Plus, CheckCircle2, Circle, Trash2, Edit, Calendar as CalendarIcon, Brain, Clock as ClockIcon } from "lucide-react";
import { format, isPast, isToday, isTomorrow } from "date-fns";
import type { Assignment } from "@shared/schema";
import { insertAssignmentSchema } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { z } from "zod";

const formSchema = insertAssignmentSchema.extend({
  dueDate: z.string().min(1, "Due date is required"),
});

type FormData = z.infer<typeof formSchema>;

const COURSE_COLORS = [
  "#facc15", "#ef4444", "#3b82f6", "#10b981", "#8b5cf6", "#f59e0b", "#ec4899", "#14b8a6"
];

export default function Assignments() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingAssignment, setEditingAssignment] = useState<Assignment | null>(null);
  const [filterStatus, setFilterStatus] = useState<"all" | "active" | "completed">("all");

  const { data: assignments, isLoading } = useQuery<Assignment[]>({ 
    queryKey: ["/api/assignments"] 
  });

  const getInsight = (assignmentId: string) => {
    return useQuery({
      queryKey: [`/api/insights/${assignmentId}`],
      enabled: !!assignmentId,
    });
  };

  const createMutation = useMutation({
    mutationFn: (data: FormData) => apiRequest("POST", "/api/assignments", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/assignments"] });
      setIsDialogOpen(false);
      form.reset();
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<Assignment> }) =>
      apiRequest("PATCH", `/api/assignments/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/assignments"] });
      setIsDialogOpen(false);
      setEditingAssignment(null);
      form.reset();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/assignments/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/assignments"] });
    },
  });

  const toggleMutation = useMutation({
    mutationFn: ({ id, completed }: { id: string; completed: boolean }) =>
      apiRequest("PATCH", `/api/assignments/${id}`, { completed }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/assignments"] });
    },
  });

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      courseName: "",
      courseColor: COURSE_COLORS[0],
      dueDate: "",
      priority: "medium",
      completed: false,
    },
  });

  const handleEdit = (assignment: Assignment) => {
    setEditingAssignment(assignment);
    form.reset({
      title: assignment.title,
      description: assignment.description || "",
      courseName: assignment.courseName,
      courseColor: assignment.courseColor,
      dueDate: format(new Date(assignment.dueDate), "yyyy-MM-dd'T'HH:mm"),
      priority: assignment.priority,
      completed: assignment.completed,
    });
    setIsDialogOpen(true);
  };

  const handleSubmit = (data: FormData) => {
    if (editingAssignment) {
      updateMutation.mutate({ id: editingAssignment.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingAssignment(null);
    form.reset();
  };

  const filteredAssignments = assignments?.filter((a) => {
    if (filterStatus === "active") return !a.completed;
    if (filterStatus === "completed") return a.completed;
    return true;
  }).sort((a, b) => {
    if (a.completed !== b.completed) return a.completed ? 1 : -1;
    return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
  }) || [];

  const getDueDateColor = (dueDate: Date, completed: boolean) => {
    if (completed) return "text-muted-foreground";
    if (isPast(dueDate)) return "text-red-400";
    if (isToday(dueDate)) return "text-orange-400";
    if (isTomorrow(dueDate)) return "text-yellow-400";
    return "text-muted-foreground";
  };

  const getDueDateText = (dueDate: Date) => {
    if (isPast(dueDate)) return "Overdue";
    if (isToday(dueDate)) return "Due today";
    if (isTomorrow(dueDate)) return "Due tomorrow";
    return format(dueDate, "MMM d, h:mm a");
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-4xl font-bold text-foreground mb-2">Assignments</h1>
          <p className="text-muted-foreground">Track and manage your coursework</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary text-primary-foreground hover-elevate" data-testid="button-new-assignment">
              <Plus className="h-4 w-4 mr-2" />
              New Assignment
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-card border-border sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>
                {editingAssignment ? "Edit Assignment" : "New Assignment"}
              </DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Assignment title" data-testid="input-title" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="courseName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Course</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="e.g., Computer Science 101" data-testid="input-course" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description (Optional)</FormLabel>
                      <FormControl>
                        <Textarea {...field} placeholder="Assignment details..." className="resize-none" rows={3} data-testid="input-description" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="dueDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Due Date</FormLabel>
                        <FormControl>
                          <Input {...field} type="datetime-local" data-testid="input-due-date" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="priority"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Priority</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-priority">
                              <SelectValue />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="low">Low</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="high">High</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="courseColor"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Color</FormLabel>
                      <FormControl>
                        <div className="flex gap-2 flex-wrap">
                          {COURSE_COLORS.map((color) => (
                            <button
                              key={color}
                              type="button"
                              className={`w-8 h-8 rounded-md hover-elevate ${
                                field.value === color ? "ring-2 ring-primary ring-offset-2 ring-offset-background" : ""
                              }`}
                              style={{ backgroundColor: color }}
                              onClick={() => field.onChange(color)}
                              data-testid={`color-${color}`}
                            />
                          ))}
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={handleCloseDialog} className="hover-elevate" data-testid="button-cancel">
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    className="bg-primary text-primary-foreground hover-elevate"
                    disabled={createMutation.isPending || updateMutation.isPending}
                    data-testid="button-save"
                  >
                    {createMutation.isPending || updateMutation.isPending ? "Saving..." : "Save"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex gap-2 mb-6">
        <Button
          variant={filterStatus === "all" ? "default" : "outline"}
          onClick={() => setFilterStatus("all")}
          className="hover-elevate"
          data-testid="filter-all"
        >
          All
        </Button>
        <Button
          variant={filterStatus === "active" ? "default" : "outline"}
          onClick={() => setFilterStatus("active")}
          className="hover-elevate"
          data-testid="filter-active"
        >
          Active
        </Button>
        <Button
          variant={filterStatus === "completed" ? "default" : "outline"}
          onClick={() => setFilterStatus("completed")}
          className="hover-elevate"
          data-testid="filter-completed"
        >
          Completed
        </Button>
      </div>

      {isLoading ? (
        <div className="text-center py-12">
          <p className="text-muted-foreground">Loading assignments...</p>
        </div>
      ) : filteredAssignments.length === 0 ? (
        <Card className="glass-card border-border">
          <CardContent className="py-12 text-center">
            <CheckCircle2 className="h-16 w-16 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-medium mb-2">No assignments found</h3>
            <p className="text-muted-foreground mb-6">
              {filterStatus === "all" ? "Create your first assignment to get started" : `No ${filterStatus} assignments`}
            </p>
            <Button 
              onClick={() => setIsDialogOpen(true)}
              className="bg-primary text-primary-foreground hover-elevate"
              data-testid="button-create-first"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Assignment
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredAssignments.map((assignment) => {
            const dueDate = new Date(assignment.dueDate);
            return (
              <Card 
                key={assignment.id} 
                className={`glass-card border-border hover-elevate ${assignment.completed ? "opacity-60" : ""}`}
                data-testid={`assignment-card-${assignment.id}`}
              >
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <button
                      onClick={() => toggleMutation.mutate({ 
                        id: assignment.id, 
                        completed: !assignment.completed 
                      })}
                      className="mt-1 hover-elevate rounded-full"
                      data-testid={`toggle-${assignment.id}`}
                    >
                      {assignment.completed ? (
                        <CheckCircle2 className="h-6 w-6 text-primary" />
                      ) : (
                        <Circle className="h-6 w-6 text-muted-foreground" />
                      )}
                    </button>
                    <div
                      className="w-1 h-16 rounded-full"
                      style={{ backgroundColor: assignment.courseColor }}
                    />
                    <div className="flex-1 min-w-0">
                      <h3 className={`text-lg font-medium mb-1 ${assignment.completed ? "line-through text-muted-foreground" : ""}`}>
                        {assignment.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-2">{assignment.courseName}</p>
                      {assignment.description && (
                        <p className="text-sm text-muted-foreground">{assignment.description}</p>
                      )}
                      <div className="flex items-center gap-4 mt-3">
                        <div className="flex items-center gap-2">
                          <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                          <span className={`text-sm font-medium ${getDueDateColor(dueDate, assignment.completed)}`}>
                            {getDueDateText(dueDate)}
                          </span>
                        </div>
                        <span className="text-xs px-2 py-1 rounded-md bg-secondary text-secondary-foreground">
                          {assignment.priority}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEdit(assignment)}
                        className="hover-elevate"
                        data-testid={`edit-${assignment.id}`}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteMutation.mutate(assignment.id)}
                        className="hover-elevate text-destructive"
                        data-testid={`delete-${assignment.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
