
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, Clock, Target, Brain, Zap } from "lucide-react";
import { format } from "date-fns";

interface StudyAnalytics {
  id: string;
  date: string;
  hourOfDay: number;
  productivityScore: number;
  focusDuration: number;
  tasksCompleted: number;
}

interface BestHour {
  hour: number;
  avgScore: number;
}

export default function Analytics() {
  const { data: analytics } = useQuery<StudyAnalytics[]>({
    queryKey: ["/api/analytics/study"],
  });

  const { data: bestHours } = useQuery<BestHour[]>({
    queryKey: ["/api/analytics/best-hours"],
  });

  const avgProductivity = analytics?.reduce((acc, a) => acc + a.productivityScore, 0) / (analytics?.length || 1);
  const totalFocusHours = (analytics?.reduce((acc, a) => acc + a.focusDuration, 0) || 0) / 3600;
  const totalTasks = analytics?.reduce((acc, a) => acc + a.tasksCompleted, 0) || 0;

  const formatHour = (hour: number) => {
    const period = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:00 ${period}`;
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-foreground mb-2">
          Study <span className="text-glow text-primary">Analytics</span>
        </h1>
        <p className="text-muted-foreground">Track your productivity patterns and optimize your study schedule</p>
      </div>

      <div className="grid gap-6 md:grid-cols-3 mb-8">
        <Card className="glass-card border-border hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Productivity</CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">
              {avgProductivity.toFixed(1)}/10
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Last 30 days
            </p>
          </CardContent>
        </Card>

        <Card className="glass-card border-border hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Focus Time</CardTitle>
            <Clock className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">
              {totalFocusHours.toFixed(1)}h
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Total deep work
            </p>
          </CardContent>
        </Card>

        <Card className="glass-card border-border hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tasks Completed</CardTitle>
            <Target className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">{totalTasks}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Study sessions
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2 mb-8">
        <Card className="glass-card border-border">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-primary" />
              <CardTitle className="text-xl">Your Peak Performance Hours</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            {!bestHours || bestHours.length === 0 ? (
              <div className="text-center py-8">
                <Brain className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                <p className="text-muted-foreground">
                  Complete more study sessions to discover your peak hours
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {bestHours.map((hour, idx) => (
                  <div
                    key={hour.hour}
                    className="flex items-center justify-between p-4 rounded-lg bg-card border border-card-border"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary font-bold">
                        {idx + 1}
                      </div>
                      <div>
                        <p className="font-medium">{formatHour(hour.hour)}</p>
                        <p className="text-sm text-muted-foreground">
                          Avg productivity: {hour.avgScore.toFixed(1)}/10
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex gap-1">
                        {Array.from({ length: 10 }).map((_, i) => (
                          <div
                            key={i}
                            className={`w-1 h-6 rounded-full ${
                              i < Math.round(hour.avgScore)
                                ? "bg-primary"
                                : "bg-secondary"
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
                <div className="mt-6 p-4 rounded-lg bg-primary/5 border border-primary/20">
                  <p className="text-sm text-primary font-medium mb-1">💡 Pro Tip</p>
                  <p className="text-sm text-muted-foreground">
                    Schedule your most challenging assignments during your peak hours for maximum productivity!
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="glass-card border-border">
          <CardHeader>
            <CardTitle className="text-xl">Recent Study Sessions</CardTitle>
          </CardHeader>
          <CardContent>
            {!analytics || analytics.length === 0 ? (
              <div className="text-center py-8">
                <Clock className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                <p className="text-muted-foreground">No study sessions recorded yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {analytics.slice(0, 8).map((session) => (
                  <div
                    key={session.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-card border border-card-border"
                  >
                    <div>
                      <p className="text-sm font-medium">
                        {format(new Date(session.date), "MMM d")} at {formatHour(session.hourOfDay)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {Math.round(session.focusDuration / 60)} mins • {session.tasksCompleted} tasks
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="text-right">
                        <p className="text-sm font-bold text-primary">
                          {session.productivityScore}/10
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
