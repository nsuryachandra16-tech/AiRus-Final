
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Brain, Sparkles, GraduationCap, Smartphone, Monitor } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { UserProfile } from "@shared/schema";

interface OnboardingProps {
  onComplete: (profile: UserProfile) => void;
}

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState(0);
  const [deviceType, setDeviceType] = useState<"mobile" | "desktop" | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    college: "",
    major: "",
    graduationYear: new Date().getFullYear() + 4,
  });

  const createProfileMutation = useMutation({
    mutationFn: (data: typeof formData) => apiRequest("POST", "/api/profile", data),
    onSuccess: (profile) => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      localStorage.setItem('onboarding_completed', 'true');
      localStorage.setItem('user_profile', JSON.stringify(profile));
      if (deviceType) {
        localStorage.setItem('device_type', deviceType);
        // Apply viewport settings
        const meta = document.querySelector('meta[name="viewport"]');
        if (meta) {
          if (deviceType === 'mobile') {
            meta.setAttribute('content', 'width=375, initial-scale=1, maximum-scale=1');
          } else {
            meta.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1');
          }
        }
        document.documentElement.setAttribute('data-device-type', deviceType);
      }
      onComplete(profile);
    },
  });

  const handleNext = () => {
    if (step === 0 && deviceType) {
      setStep(1);
    } else if (step === 1 && formData.name.trim()) {
      setStep(2);
    } else if (step === 2) {
      createProfileMutation.mutate(formData);
    }
  };

  const handleDeviceSelect = (type: "mobile" | "desktop") => {
    setDeviceType(type);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <Card className="glass-card border-border max-w-2xl w-full relative z-10 overflow-hidden">
        {/* Header with gradient */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary/0 via-primary to-primary/0"></div>
        
        <CardHeader className="text-center space-y-4 pt-12 pb-8">
          <div className="flex justify-center mb-4">
            <div className="relative">
              <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full"></div>
              <div className="relative bg-primary/10 p-6 rounded-2xl border border-primary/20">
                <Brain className="h-12 w-12 text-primary" />
              </div>
            </div>
          </div>
          
          <div>
            <h1 className="text-6xl font-black mb-4">
              Welcome to{" "}
              <span className="bg-gradient-to-r from-primary via-yellow-400 to-amber-500 bg-clip-text text-transparent animate-gradient text-shadow-glow">
                AiRus
              </span>
            </h1>
            <p className="text-xl text-muted-foreground font-medium flex items-center justify-center gap-2">
              <Sparkles className="h-6 w-6 text-primary animate-pulse" />
              Your Premium AI-Powered College Companion
              <Sparkles className="h-6 w-6 text-primary animate-pulse" />
            </p>
          </div>
        </CardHeader>

        <CardContent className="px-8 pb-12">
          {step === 0 && (
            <div className="space-y-8 animate-in fade-in duration-500">
              <div className="text-center mb-8">
                <h2 className="text-2xl font-semibold mb-2">Choose Your Device</h2>
                <p className="text-muted-foreground">Select how you'll primarily use AiRus</p>
              </div>

              <div className="grid grid-cols-2 gap-4 max-w-xl mx-auto">
                <button
                  onClick={() => handleDeviceSelect("mobile")}
                  className={`p-8 rounded-2xl border-2 transition-all hover-elevate ${
                    deviceType === "mobile"
                      ? "border-primary bg-primary/10"
                      : "border-border/50 bg-background/50 hover:border-primary/50"
                  }`}
                >
                  <Smartphone className={`h-16 w-16 mx-auto mb-4 ${
                    deviceType === "mobile" ? "text-primary" : "text-muted-foreground"
                  }`} />
                  <h3 className="font-semibold text-lg mb-2">Mobile</h3>
                  <p className="text-sm text-muted-foreground">Optimized for phones</p>
                </button>

                <button
                  onClick={() => handleDeviceSelect("desktop")}
                  className={`p-8 rounded-2xl border-2 transition-all hover-elevate ${
                    deviceType === "desktop"
                      ? "border-primary bg-primary/10"
                      : "border-border/50 bg-background/50 hover:border-primary/50"
                  }`}
                >
                  <Monitor className={`h-16 w-16 mx-auto mb-4 ${
                    deviceType === "desktop" ? "text-primary" : "text-muted-foreground"
                  }`} />
                  <h3 className="font-semibold text-lg mb-2">Desktop</h3>
                  <p className="text-sm text-muted-foreground">Full screen experience</p>
                </button>
              </div>

              <div className="max-w-md mx-auto">
                <Button
                  onClick={handleNext}
                  disabled={!deviceType}
                  className="w-full h-14 text-lg font-semibold bg-primary hover:bg-primary/90 text-background transition-all hover-elevate"
                >
                  Continue
                </Button>
              </div>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-8 animate-in fade-in duration-500">
              <div className="text-center mb-8">
                <GraduationCap className="h-16 w-16 text-primary mx-auto mb-4 opacity-80" />
                <h2 className="text-2xl font-semibold mb-2">Let's get to know you</h2>
                <p className="text-muted-foreground">Tell us your name to personalize your experience</p>
              </div>

              <div className="space-y-4 max-w-md mx-auto">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-base">What should we call you?</Label>
                  <Input
                    id="name"
                    placeholder="Enter your name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="text-lg h-14 bg-background/50 border-border/50 focus:border-primary transition-all"
                    autoFocus
                    onKeyDown={(e) => e.key === "Enter" && handleNext()}
                  />
                </div>

                <Button
                  onClick={handleNext}
                  disabled={!formData.name.trim()}
                  className="w-full h-14 text-lg font-semibold bg-primary hover:bg-primary/90 text-background transition-all hover-elevate"
                >
                  Continue
                </Button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6 animate-in fade-in duration-500">
              <div className="text-center mb-6">
                <h2 className="text-2xl font-semibold mb-2">Complete your profile</h2>
                <p className="text-muted-foreground">Help us customize your experience (optional)</p>
              </div>

              <div className="space-y-4 max-w-md mx-auto">
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your.email@college.edu"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="bg-background/50 border-border/50 focus:border-primary transition-all"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="college">College/University</Label>
                  <Input
                    id="college"
                    placeholder="Your institution name"
                    value={formData.college}
                    onChange={(e) => setFormData({ ...formData, college: e.target.value })}
                    className="bg-background/50 border-border/50 focus:border-primary transition-all"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="major">Major/Field of Study</Label>
                  <Input
                    id="major"
                    placeholder="e.g., Computer Science"
                    value={formData.major}
                    onChange={(e) => setFormData({ ...formData, major: e.target.value })}
                    className="bg-background/50 border-border/50 focus:border-primary transition-all"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="year">Expected Graduation Year</Label>
                  <Input
                    id="year"
                    type="number"
                    placeholder="2028"
                    value={formData.graduationYear}
                    onChange={(e) => setFormData({ ...formData, graduationYear: parseInt(e.target.value) })}
                    className="bg-background/50 border-border/50 focus:border-primary transition-all"
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    onClick={() => setStep(1)}
                    variant="outline"
                    className="flex-1 h-12 hover-elevate"
                  >
                    Back
                  </Button>
                  <Button
                    onClick={handleNext}
                    disabled={createProfileMutation.isPending}
                    className="flex-1 h-12 bg-primary hover:bg-primary/90 text-background font-semibold hover-elevate"
                  >
                    {createProfileMutation.isPending ? "Creating..." : "Get Started"}
                  </Button>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
