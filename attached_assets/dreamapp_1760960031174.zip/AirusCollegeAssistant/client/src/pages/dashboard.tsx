import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Calendar, ClipboardList, Brain, Clock, CheckCircle2, AlertCircle } from "lucide-react";
import type { Assignment, ScheduleEvent, StudySession } from "@shared/schema";
import { format, isToday, isTomorrow, isPast } from "date-fns";

export default function Dashboard() {
  const { data: assignments } = useQuery<Assignment[]>({ queryKey: ["/api/assignments"] });
  const { data: events } = useQuery<ScheduleEvent[]>({ queryKey: ["/api/schedule"] });
  const { data: sessions } = useQuery<StudySession[]>({ queryKey: ["/api/study-sessions"] });

  const upcomingAssignments = assignments
    ?.filter((a) => !a.completed)
    .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
    .slice(0, 5) || [];

  const todayEvents = events
    ?.filter((e) => {
      const eventDate = new Date(e.startTime);
      return isToday(eventDate);
    })
    .sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime()) || [];

  const totalStudyTime = sessions?.reduce((acc, s) => acc + (s.duration || 0), 0) || 0;
  const totalStudyHours = Math.floor(totalStudyTime / 3600);

  const overdueCount = assignments?.filter((a) => !a.completed && isPast(new Date(a.dueDate))).length || 0;
  const completedCount = assignments?.filter((a) => a.completed).length || 0;

  const getDueDateColor = (dueDate: Date) => {
    if (isPast(dueDate)) return "text-red-400";
    if (isToday(dueDate)) return "text-orange-400";
    if (isTomorrow(dueDate)) return "text-yellow-400";
    return "text-muted-foreground";
  };

  const getDueDateText = (dueDate: Date) => {
    if (isPast(dueDate)) return "Overdue";
    if (isToday(dueDate)) return "Due today";
    if (isTomorrow(dueDate)) return "Due tomorrow";
    return format(dueDate, "MMM d");
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-12 text-center">
        <div className="inline-block mb-6 relative">
          <div className="absolute inset-0 bg-primary/20 blur-3xl rounded-full"></div>
          <h1 className="relative text-6xl font-black mb-3">
            Welcome to{" "}
            <span className="bg-gradient-to-r from-primary via-yellow-400 to-amber-500 bg-clip-text text-transparent animate-gradient text-shadow-glow">
              AiRus
            </span>
          </h1>
        </div>
        <p className="text-xl text-muted-foreground font-medium">Your Premium AI-Powered College Companion ✨</p>
      </div>

      <div className="grid gap-6 md:grid-cols-3 mb-12">
        <Card className="glass-card border-border hover-elevate relative overflow-hidden group">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-yellow-400 to-amber-500"></div>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-semibold">Active Assignments</CardTitle>
            <div className="p-2 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
              <ClipboardList className="h-5 w-5 text-primary" strokeWidth={2.5} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-black bg-gradient-to-r from-primary to-yellow-400 bg-clip-text text-transparent">
              {assignments?.filter((a) => !a.completed).length || 0}
            </div>
            <p className="text-sm text-muted-foreground mt-2 font-medium">
              {completedCount} completed
            </p>
          </CardContent>
        </Card>

        <Card className="glass-card border-border hover-elevate relative overflow-hidden group">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-yellow-400 to-amber-500"></div>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-semibold">Study Time</CardTitle>
            <div className="p-2 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
              <Clock className="h-5 w-5 text-primary" strokeWidth={2.5} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-black bg-gradient-to-r from-primary to-yellow-400 bg-clip-text text-transparent">
              {totalStudyHours}h
            </div>
            <p className="text-sm text-muted-foreground mt-2 font-medium">
              {sessions?.length || 0} sessions
            </p>
          </CardContent>
        </Card>

        <Card className="glass-card border-border hover-elevate relative overflow-hidden group">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-yellow-400 to-amber-500"></div>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-semibold">Today's Classes</CardTitle>
            <div className="p-2 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
              <Calendar className="h-5 w-5 text-primary" strokeWidth={2.5} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-black bg-gradient-to-r from-primary to-yellow-400 bg-clip-text text-transparent">
              {todayEvents.length}
            </div>
            <p className="text-sm text-muted-foreground mt-2 font-medium">
              {events?.length || 0} total events
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="glass-card border-border">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl">Upcoming Assignments</CardTitle>
              <Link href="/assignments">
                <Button variant="ghost" size="sm" className="text-primary hover-elevate" data-testid="link-view-all-assignments">
                  View All
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            {upcomingAssignments.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle2 className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                <p className="text-muted-foreground">No upcoming assignments</p>
                <Link href="/assignments">
                  <Button variant="outline" size="sm" className="mt-4 hover-elevate" data-testid="button-add-assignment">
                    Add Assignment
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                {upcomingAssignments.map((assignment) => {
                  const dueDate = new Date(assignment.dueDate);
                  return (
                    <div
                      key={assignment.id}
                      className="flex items-start gap-3 p-3 rounded-lg hover-elevate"
                      data-testid={`assignment-${assignment.id}`}
                    >
                      <div
                        className="w-1 h-12 rounded-full"
                        style={{ backgroundColor: assignment.courseColor }}
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-foreground truncate">{assignment.title}</h4>
                        <p className="text-sm text-muted-foreground">{assignment.courseName}</p>
                      </div>
                      <div className="text-right">
                        <p className={`text-sm font-medium ${getDueDateColor(dueDate)}`}>
                          {getDueDateText(dueDate)}
                        </p>
                        <p className="text-xs text-muted-foreground">{format(dueDate, "h:mm a")}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="glass-card border-border">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl">Today's Schedule</CardTitle>
              <Link href="/schedule">
                <Button variant="ghost" size="sm" className="text-primary hover-elevate" data-testid="link-view-schedule">
                  View Calendar
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            {todayEvents.length === 0 ? (
              <div className="text-center py-8">
                <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                <p className="text-muted-foreground">No classes today</p>
              </div>
            ) : (
              <div className="space-y-4">
                {todayEvents.map((event) => {
                  const startTime = new Date(event.startTime);
                  const endTime = new Date(event.endTime);
                  return (
                    <div
                      key={event.id}
                      className="flex items-start gap-3 p-3 rounded-lg hover-elevate"
                      data-testid={`event-${event.id}`}
                    >
                      <div
                        className="w-1 h-12 rounded-full"
                        style={{ backgroundColor: event.courseColor }}
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-foreground truncate">{event.title}</h4>
                        <p className="text-sm text-muted-foreground">{event.courseName}</p>
                        {event.location && (
                          <p className="text-xs text-muted-foreground">{event.location}</p>
                        )}
                      </div>
                      <div className="text-right font-mono text-sm text-muted-foreground">
                        <div>{format(startTime, "h:mm a")}</div>
                        <div>{format(endTime, "h:mm a")}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Link href="/assignments">
          <Card className="glass-card border-border hover-elevate active-elevate-2 cursor-pointer group" data-testid="card-assignments">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-primary/10">
                  <ClipboardList className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Assignments</h3>
                  <p className="text-sm text-muted-foreground">Track tasks</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>

        <Link href="/schedule">
          <Card className="glass-card border-border hover-elevate active-elevate-2 cursor-pointer group" data-testid="card-schedule">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-primary/10">
                  <Calendar className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Schedule</h3>
                  <p className="text-sm text-muted-foreground">View calendar</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>

        <Link href="/study">
          <Card className="glass-card border-border hover-elevate active-elevate-2 cursor-pointer group" data-testid="card-study">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-primary/10">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Study Timer</h3>
                  <p className="text-sm text-muted-foreground">Focus time</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>

        <Link href="/tutor">
          <Card className="glass-card border-border hover-elevate active-elevate-2 cursor-pointer group" data-testid="card-tutor">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-primary/10">
                  <Brain className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">AI Tutor</h3>
                  <p className="text-sm text-muted-foreground">Get help</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>
      </div>
    </div>
  );
}
