// Client-side implementation in a component (for example: `tutor.tsx`)
import React, { useState } from "react";

const ChatBox = () => {
  const [userMessage, setUserMessage] = useState("");
  const [conversationHistory, setConversationHistory] = useState([]);

  const sendMessage = async () => {
    const response = await chatWithTutor(userMessage, conversationHistory);
    setConversationHistory([
      ...conversationHistory,
      { role: "user", content: userMessage },
      { role: "ai", content: response },
    ]);
    setUserMessage("");
  };

  return (
    <div className="chatbox">
      {conversationHistory.map((message, index) => (
        <div key={index} className={message.role}>
          {message.content}
        </div>
      ))}
      <input
        type="text"
        value={userMessage}
        onChange={(e) => setUserMessage(e.target.value)}
        onKeyPress={(e) => {
          if (e.key === "Enter") sendMessage();
        }}
      />
      <button onClick={sendMessage}>Send</button>
    </div>
  );
};

export default ChatBox;

// Function to communicate with the AI (Make sure you import this as needed)
async function chatWithTutor(userMessage, conversationHistory) {
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userMessage, conversationHistory }),
    });
    const data = await response.json();
    return data.reply; // Adjust based on your API response
  } catch (error) {
    console.error("Error communicating with the AI:", error);
    return "There was an error. Please try again.";
  }
}
