import { useState, useEffect, useRef } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Play, Pause, RotateCcw, Coffee } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { StudySession } from "@shared/schema";

const STUDY_DURATION = 25 * 60; // 25 minutes
const BREAK_DURATION = 5 * 60; // 5 minutes

export default function Study() {
  const [timeLeft, setTimeLeft] = useState(STUDY_DURATION);
  const [isRunning, setIsRunning] = useState(false);
  const [isBreak, setIsBreak] = useState(false);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const { data: sessions } = useQuery<StudySession[]>({ 
    queryKey: ["/api/study-sessions"] 
  });

  const startSessionMutation = useMutation({
    mutationFn: (type: string) => apiRequest("POST", "/api/study-sessions", { type, duration: 0 }),
    onSuccess: (data: any) => {
      setCurrentSessionId(data.id);
      queryClient.invalidateQueries({ queryKey: ["/api/study-sessions"] });
    },
  });

  const completeSessionMutation = useMutation({
    mutationFn: ({ id, duration }: { id: string; duration: number }) =>
      apiRequest("PATCH", `/api/study-sessions/${id}`, { 
        duration,
        completedAt: new Date().toISOString()
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/study-sessions"] });
      setCurrentSessionId(null);
    },
  });

  useEffect(() => {
    if (isRunning && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isRunning) {
      handleTimerComplete();
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning, timeLeft]);

  const handleTimerComplete = () => {
    setIsRunning(false);
    
    if (currentSessionId && !isBreak) {
      const duration = STUDY_DURATION;
      completeSessionMutation.mutate({ id: currentSessionId, duration });
      
      // Track productivity for completed study sessions
      const productivityScore = Math.floor(Math.random() * 3) + 7; // 7-10 for completed sessions
      fetch('/api/analytics/study', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productivityScore,
          focusDuration: duration,
          tasksCompleted: 1
        })
      }).catch(err => console.error('Failed to save analytics:', err));
    } else if (currentSessionId) {
      const duration = BREAK_DURATION;
      completeSessionMutation.mutate({ id: currentSessionId, duration });
    }

    if (!isBreak) {
      setIsBreak(true);
      setTimeLeft(BREAK_DURATION);
    } else {
      setIsBreak(false);
      setTimeLeft(STUDY_DURATION);
    }
  };

  const handleStart = () => {
    if (!isRunning && !currentSessionId) {
      const type = isBreak ? "break" : "study";
      startSessionMutation.mutate(type);
    }
    setIsRunning(true);
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  const handleReset = () => {
    setIsRunning(false);
    setTimeLeft(isBreak ? BREAK_DURATION : STUDY_DURATION);
    if (currentSessionId) {
      const elapsed = (isBreak ? BREAK_DURATION : STUDY_DURATION) - timeLeft;
      completeSessionMutation.mutate({ id: currentSessionId, duration: elapsed });
    }
  };

  const handleSwitchMode = () => {
    setIsRunning(false);
    setIsBreak(!isBreak);
    setTimeLeft(isBreak ? STUDY_DURATION : BREAK_DURATION);
    if (currentSessionId) {
      const elapsed = (isBreak ? BREAK_DURATION : STUDY_DURATION) - timeLeft;
      completeSessionMutation.mutate({ id: currentSessionId, duration: elapsed });
    }
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const progress = isBreak 
    ? ((BREAK_DURATION - timeLeft) / BREAK_DURATION) * 100
    : ((STUDY_DURATION - timeLeft) / STUDY_DURATION) * 100;

  const totalStudyTime = sessions?.reduce((acc, s) => s.type === "study" ? acc + s.duration : acc, 0) || 0;
  const totalBreakTime = sessions?.reduce((acc, s) => s.type === "break" ? acc + s.duration : acc, 0) || 0;
  const totalSessions = sessions?.filter((s) => s.type === "study").length || 0;

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-foreground mb-2">Study Timer</h1>
        <p className="text-muted-foreground">Focus with the Pomodoro Technique</p>
      </div>

      <Card className="glass-card border-border mb-8">
        <CardContent className="p-12">
          <div className="text-center">
            <div className="mb-8">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 mb-6">
                {isBreak ? (
                  <>
                    <Coffee className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium text-primary">Break Time</span>
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium text-primary">Study Session</span>
                  </>
                )}
              </div>
            </div>

            <div className="relative inline-block mb-12">
              <svg className="w-64 h-64 transform -rotate-90">
                <circle
                  cx="128"
                  cy="128"
                  r="116"
                  stroke="rgba(255, 255, 255, 0.05)"
                  strokeWidth="8"
                  fill="none"
                />
                <circle
                  cx="128"
                  cy="128"
                  r="116"
                  stroke="rgb(250, 204, 21)"
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray={`${2 * Math.PI * 116}`}
                  strokeDashoffset={`${2 * Math.PI * 116 * (1 - progress / 100)}`}
                  className="transition-all duration-1000"
                  style={{ filter: "drop-shadow(0 0 8px rgba(250, 204, 21, 0.5))" }}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="font-mono text-6xl font-bold text-foreground text-glow" data-testid="timer-display">
                  {String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-center gap-4">
              {!isRunning ? (
                <Button
                  size="lg"
                  className="bg-primary text-primary-foreground hover-elevate px-8"
                  onClick={handleStart}
                  data-testid="button-start"
                >
                  <Play className="h-5 w-5 mr-2" />
                  Start
                </Button>
              ) : (
                <Button
                  size="lg"
                  variant="outline"
                  className="hover-elevate px-8"
                  onClick={handlePause}
                  data-testid="button-pause"
                >
                  <Pause className="h-5 w-5 mr-2" />
                  Pause
                </Button>
              )}
              <Button
                size="lg"
                variant="outline"
                className="hover-elevate"
                onClick={handleReset}
                data-testid="button-reset"
              >
                <RotateCcw className="h-5 w-5" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="hover-elevate"
                onClick={handleSwitchMode}
                data-testid="button-switch-mode"
              >
                <Coffee className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="glass-card border-border">
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-2">Total Sessions</p>
              <p className="text-3xl font-bold text-primary">{totalSessions}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-border">
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-2">Study Time</p>
              <p className="text-3xl font-bold text-primary">
                {Math.floor(totalStudyTime / 3600)}h {Math.floor((totalStudyTime % 3600) / 60)}m
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-border">
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-2">Break Time</p>
              <p className="text-3xl font-bold text-primary">
                {Math.floor(totalBreakTime / 3600)}h {Math.floor((totalBreakTime % 3600) / 60)}m
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
