
import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, Calendar, Clock, MapPin, Trash2, FileText } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { TimetableEntry, FreeSlot, WorkItem } from "@shared/schema";
import { format } from "date-fns";

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export default function Timetable() {
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const workInputRef = useRef<HTMLInputElement>(null);

  const { data: timetable } = useQuery<TimetableEntry[]>({ 
    queryKey: ["/api/timetable"] 
  });

  const { data: freeSlots } = useQuery<FreeSlot[]>({ 
    queryKey: ["/api/slots"] 
  });

  const { data: workItems } = useQuery<WorkItem[]>({ 
    queryKey: ["/api/work"] 
  });

  const uploadTimetableMutation = useMutation({
    mutationFn: async (base64: string) => {
      return apiRequest("POST", "/api/timetable/upload", { image: base64 });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/timetable"] });
      queryClient.invalidateQueries({ queryKey: ["/api/slots"] });
      setUploading(false);
    },
  });

  const uploadWorkMutation = useMutation({
    mutationFn: async (base64: string) => {
      return apiRequest("POST", "/api/work/upload", { image: base64 });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/work"] });
      queryClient.invalidateQueries({ queryKey: ["/api/slots"] });
    },
  });

  const deleteWorkMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/work/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/work"] });
    },
  });

  const handleTimetableUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result?.toString().split(',')[1];
      if (base64) {
        uploadTimetableMutation.mutate(base64);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleWorkUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result?.toString().split(',')[1];
      if (base64) {
        uploadWorkMutation.mutate(base64);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-foreground mb-2">Smart Timetable</h1>
        <p className="text-muted-foreground">Upload your timetable and manage work assignments</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2 mb-8">
        <Card className="glass-card border-border">
          <CardHeader>
            <CardTitle className="text-xl">Upload Timetable</CardTitle>
          </CardHeader>
          <CardContent>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleTimetableUpload}
              className="hidden"
            />
            <Button
              className="w-full bg-primary text-primary-foreground hover-elevate"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
            >
              <Upload className="h-4 w-4 mr-2" />
              {uploading ? "Analyzing..." : "Upload Timetable Image"}
            </Button>
            <p className="text-sm text-muted-foreground mt-4">
              Upload a photo of your college timetable. AI will extract your class schedule automatically.
            </p>
          </CardContent>
        </Card>

        <Card className="glass-card border-border">
          <CardHeader>
            <CardTitle className="text-xl">Upload Work</CardTitle>
          </CardHeader>
          <CardContent>
            <input
              ref={workInputRef}
              type="file"
              accept="image/*"
              onChange={handleWorkUpload}
              className="hidden"
            />
            <Button
              className="w-full bg-primary text-primary-foreground hover-elevate"
              onClick={() => workInputRef.current?.click()}
              disabled={uploadWorkMutation.isPending}
            >
              <FileText className="h-4 w-4 mr-2" />
              {uploadWorkMutation.isPending ? "Analyzing..." : "Upload Assignment/Work"}
            </Button>
            <p className="text-sm text-muted-foreground mt-4">
              Upload homework or assignment photos. AI will analyze and schedule them in free slots.
            </p>
          </CardContent>
        </Card>
      </div>

      {timetable && timetable.length > 0 && (
        <Card className="glass-card border-border mb-8">
          <CardHeader>
            <CardTitle>Your Schedule</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {DAYS.map((day, idx) => {
                const dayClasses = timetable.filter(t => t.dayOfWeek === idx);
                if (dayClasses.length === 0) return null;

                return (
                  <div key={idx}>
                    <h3 className="text-lg font-semibold mb-3 text-primary">{day}</h3>
                    <div className="space-y-2">
                      {dayClasses.map((entry) => (
                        <div
                          key={entry.id}
                          className="flex items-center gap-4 p-3 rounded-lg bg-card border border-card-border"
                        >
                          <div className="flex-1">
                            <p className="font-medium">{entry.subject}</p>
                            <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {entry.startTime} - {entry.endTime}
                              </span>
                              {entry.location && (
                                <span className="flex items-center gap-1">
                                  <MapPin className="h-3 w-3" />
                                  {entry.location}
                                </span>
                              )}
                            </div>
                          </div>
                          <span className="text-xs px-2 py-1 rounded-md bg-primary/10 text-primary">
                            {entry.type}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {workItems && workItems.length > 0 && (
        <Card className="glass-card border-border mb-8">
          <CardHeader>
            <CardTitle>Scheduled Work</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {workItems.map((work) => (
                <div
                  key={work.id}
                  className="flex items-start gap-4 p-4 rounded-lg bg-card border border-card-border"
                >
                  <div className="flex-1">
                    <h4 className="font-medium mb-1">{work.title}</h4>
                    <p className="text-sm text-muted-foreground mb-2">{work.description}</p>
                    <div className="flex items-center gap-4 text-sm">
                      <span className="text-primary">{work.subject}</span>
                      <span>{work.estimatedDuration} mins</span>
                      <span className="text-xs px-2 py-1 rounded-md bg-secondary">
                        {work.priority}
                      </span>
                      {work.scheduledSlotId && (
                        <span className="text-green-400">✓ Scheduled</span>
                      )}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => deleteWorkMutation.mutate(work.id)}
                    className="hover-elevate text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {freeSlots && freeSlots.length > 0 && (
        <Card className="glass-card border-border">
          <CardHeader>
            <CardTitle>Available Free Slots</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {DAYS.map((day, idx) => {
                const daySlots = freeSlots.filter(s => s.dayOfWeek === idx && s.isAvailable);
                if (daySlots.length === 0) return null;

                return (
                  <div key={idx}>
                    <h3 className="text-md font-semibold mb-2 text-muted-foreground">{day}</h3>
                    <div className="grid gap-2 sm:grid-cols-2">
                      {daySlots.map((slot) => (
                        <div
                          key={slot.id}
                          className="flex items-center justify-between p-2 rounded bg-primary/5 border border-primary/20"
                        >
                          <span className="text-sm">
                            {slot.startTime} - {slot.endTime}
                          </span>
                          <span className="text-xs text-primary">
                            {slot.duration} mins
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
