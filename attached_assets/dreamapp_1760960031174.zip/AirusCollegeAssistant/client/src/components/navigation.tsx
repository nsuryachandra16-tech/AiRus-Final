
import { Link, useLocation } from "wouter";
import { Home, ClipboardList, Calendar, Clock, Brain, FileSpreadsheet, TrendingUp, User, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

interface NavigationProps {
  userName?: string;
}

export default function Navigation({ userName }: NavigationProps) {
  const [location] = useLocation();
  
  const displayName = userName || (() => {
    try {
      const storedProfile = localStorage.getItem('user_profile');
      if (storedProfile) {
        const profile = JSON.parse(storedProfile);
        return profile.name;
      }
    } catch (e) {
      // Ignore parsing errors
    }
    return null;
  })();

  const navItems = [
    { path: "/", icon: Home, label: "Dashboard" },
    { path: "/assignments", icon: ClipboardList, label: "Assignments" },
    { path: "/schedule", icon: Calendar, label: "Schedule" },
    { path: "/study", icon: Clock, label: "Study" },
    { path: "/timetable", icon: FileSpreadsheet, label: "Timetable" },
    { path: "/tutor", icon: Brain, label: "AI Tutor" },
    { path: "/analytics", icon: TrendingUp, label: "Analytics" },
  ];

  return (
    <nav className="sticky top-0 z-50 glass-card border-b border-border/30 backdrop-blur-xl">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center gap-8">
            <Link href="/">
              <div className="flex items-center gap-3 cursor-pointer group">
                {/* Premium Custom Logo */}
                <div className="relative">
                  <div className="absolute inset-0 bg-primary/30 blur-2xl rounded-full animate-pulse"></div>
                  <div className="relative bg-gradient-to-br from-primary via-yellow-400 to-amber-500 p-3 rounded-2xl shadow-2xl transform transition-all duration-300 group-hover:scale-110 group-hover:rotate-3">
                    <div className="relative">
                      <Brain className="h-7 w-7 text-gray-900" strokeWidth={2.5} />
                      <Zap className="h-3 w-3 text-gray-900 absolute -top-1 -right-1 animate-pulse" />
                    </div>
                  </div>
                </div>
                
                {/* Logo Text */}
                <div className="flex flex-col">
                  <span className="text-3xl font-black tracking-tight bg-gradient-to-r from-primary via-yellow-400 to-amber-500 bg-clip-text text-transparent">
                    AiRus
                  </span>
                  <span className="text-[10px] font-semibold text-muted-foreground tracking-widest uppercase -mt-1">
                    AI Assistant
                  </span>
                </div>
              </div>
            </Link>
            
            {displayName && (
              <div className="hidden lg:flex items-center gap-3 px-5 py-2.5 rounded-full bg-gradient-to-r from-primary/10 via-yellow-400/10 to-amber-500/10 border border-primary/20 shadow-lg">
                <div className="w-2 h-2 rounded-full bg-primary animate-pulse"></div>
                <span className="text-sm font-bold bg-gradient-to-r from-primary to-yellow-400 bg-clip-text text-transparent">
                  Hey, {displayName}!
                </span>
              </div>
            )}
          </div>

          <div className="hidden md:flex items-center gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.path;
              return (
                <Link key={item.path} href={item.path}>
                  <Button
                    variant={isActive ? "default" : "ghost"}
                    className={`relative overflow-hidden transition-all duration-300 ${
                      isActive 
                        ? "bg-gradient-to-r from-primary via-yellow-400 to-amber-500 text-gray-900 font-semibold shadow-xl shadow-primary/25" 
                        : "hover:bg-primary/5 hover:text-primary"
                    }`}
                    data-testid={`nav-${item.label.toLowerCase().replace(" ", "-")}`}
                  >
                    {isActive && (
                      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-shimmer"></div>
                    )}
                    <Icon className="h-4 w-4 mr-2" strokeWidth={2.5} />
                    {item.label}
                  </Button>
                </Link>
              );
            })}
          </div>

          <div className="md:hidden flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.path;
              return (
                <Link key={item.path} href={item.path}>
                  <Button
                    variant={isActive ? "default" : "ghost"}
                    size="icon"
                    className={`transition-all duration-300 ${
                      isActive 
                        ? "bg-gradient-to-br from-primary to-yellow-400 text-gray-900 shadow-lg shadow-primary/30" 
                        : "hover:bg-primary/5 hover:text-primary"
                    }`}
                    data-testid={`nav-${item.label.toLowerCase().replace(" ", "-")}`}
                  >
                    <Icon className="h-4 w-4" strokeWidth={2.5} />
                  </Button>
                </Link>
              );
            })}
          </div>
        </div>
        
        <div className="text-center py-3 border-t border-border/20 bg-gradient-to-r from-transparent via-primary/5 to-transparent">
          <p className="text-xs font-medium text-muted-foreground">
            Crafted with <span className="text-primary">❤</span> by{" "}
            <span className="font-bold bg-gradient-to-r from-primary to-yellow-400 bg-clip-text text-transparent">
              Surya
            </span>
          </p>
        </div>
      </div>
    </nav>
  );
}
