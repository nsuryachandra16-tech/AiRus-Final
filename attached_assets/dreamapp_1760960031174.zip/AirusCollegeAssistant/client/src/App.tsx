import { useState, useEffect } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider, useQuery } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Navigation from "@/components/navigation";
import Dashboard from "@/pages/dashboard";
import Assignments from "@/pages/assignments";
import Schedule from "@/pages/schedule";
import Study from "@/pages/study";
import Tutor from "@/pages/tutor";
import Timetable from "@/pages/timetable";
import Analytics from "@/pages/analytics";
import Onboarding from "@/pages/onboarding";
import NotFound from "@/pages/not-found";
import type { UserProfile } from "@shared/schema";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/assignments" component={Assignments} />
      <Route path="/schedule" component={Schedule} />
      <Route path="/study" component={Study} />
      <Route path="/tutor" component={Tutor} />
      <Route path="/timetable" component={Timetable} />
      <Route path="/analytics" component={Analytics} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  const [showOnboarding, setShowOnboarding] = useState(false);
  const { data: profile, isLoading } = useQuery<UserProfile | null>({
    queryKey: ["/api/profile"],
  });

  useEffect(() => {
    // Check localStorage first
    const hasCompletedOnboarding = localStorage.getItem('onboarding_completed');
    
    if (profile) {
      setShowOnboarding(false);
      localStorage.setItem('onboarding_completed', 'true');
    } else if (!isLoading && !profile && !hasCompletedOnboarding) {
      setShowOnboarding(true);
    } else if (!isLoading && !profile && hasCompletedOnboarding) {
      // Profile exists in localStorage but not in server (server restarted)
      setShowOnboarding(false);
    }
  }, [profile, isLoading]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent mb-4"></div>
          <p className="text-muted-foreground">Loading AiRus...</p>
        </div>
      </div>
    );
  }

  if (showOnboarding) {
    return <Onboarding onComplete={() => setShowOnboarding(false)} />;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation userName={profile?.name} />
      <Router />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AppContent />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;